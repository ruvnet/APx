# APx · Agentic Power

A proposed reference measure for useful human and agent output, with a cinematic Three.js explanation and a runnable benchmark.

AP = accepted reference human work hours / complete elapsed hours.
APx = log₂(AP).

At 8 AP, APx is 3. The quantity is task and cohort specific, not an intelligence score.

## Open the specification

Read [APx specification](docs/APx-Specification.md), [research brief](docs/APx-Research.md), and [benchmark contract](benchmark/docs/CONTRACT.md). All example cohorts, workflow durations and productivity values are synthetic. rUv’s personal score is not measured.

## Run the benchmark

Node 22 or newer. No dependencies, model access, or API key required for the tutorial.

```bash
node benchmark/bin/apx.mjs demo
node benchmark/bin/apx.mjs demo | node benchmark/bin/apx.mjs evaluate -
cd benchmark
node --test test/core.test.mjs .harness/generate.test.mjs
node src/mcp.mjs
```

The tutorial executes three bounded toy computations. Their actual local runtime is distinct from synthetic human calibration and workflow time. The result is 9 AP and APx about 3.169925, explicitly synthetic and uncertified.

Native build governance check, requiring access to the pinned public package:

```bash
npx -y @metaharness/darwin@0.10.2 bench verify .harness/bench.development.json
```

This verifies a visible conformance suite hash. It does not create a hidden occupational holdout or run evolution.

## Integration boundaries

Ruflo coordinates. MetaHarness governs build evaluation. Autogenous and ruClip have explicit local APx contract adapters, not a claim of live native compatibility. Independent human calibration and acceptance remain external trust boundaries. The scorer never issues a certificate or deployment authority.

The package includes twelve proposed task profiles. None is a calibrated occupational benchmark. All high stakes profiles are research, administration, or simulation only.

## Site

The Site uses the supplied Vinext/React project, Three.js 0.180.0, physically based lighting and materials, time replay controls, accessible UI primitives, responsive layouts, and a reduced motion path. The calculator is cross checked against the reference kernel.

```bash
npm run build
node --test tests/*.test.mjs
npx tsc --noEmit --project tsconfig.apx.json
```

Use the Sites lifecycle helpers for hosting. Do not place credentials in the repository.

## Verification and remaining limits

See [verification](docs/VERIFICATION.md). The tested boundaries include safety ineligibility, duplicate aliases, measurement receipt binding, incomplete tasks, unmetered costs, and human labor regression.

Hashes and declarations do not prove truth. The current bootstrap interval is conditional on a frozen baseline and excludes population calibration uncertainty. No live Autogenous or ruClip service, paid model benchmark, or human cohort was exercised. Browser visual QA was not requested and is not claimed.

APx is distinct from Mercor’s APEX benchmark family. No naming clearance, standards adoption, or IP novelty claim is made.
